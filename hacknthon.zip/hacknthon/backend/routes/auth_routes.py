from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from ..database import db
from ..models.user import create_user

auth_routes = Blueprint('auth_routes', __name__)

@auth_routes.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    if not username:
        return jsonify({"status": "error", "message": "Username required"}), 400
    user = db.users.find_one({"username": username})
    if not user:
        user_id = db.users.insert_one(create_user(username)).inserted_id
        user = db.users.find_one({"_id": ObjectId(user_id)})
    user['_id'] = str(user['_id'])
    return jsonify({"status": "success", "user": user})
