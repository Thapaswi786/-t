from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from ..database import db

volunteer_routes = Blueprint('volunteer_routes', __name__)

@volunteer_routes.route('/volunteers', methods=['GET'])
def get_volunteers():
    volunteers = list(db.volunteer_events.find())
    for v in volunteers:
        v['_id'] = str(v['_id'])
    return jsonify(volunteers)

@volunteer_routes.route('/register/<event_id>', methods=['POST'])
def register_event(event_id):
    data = request.json
    username = data.get('username')
    if not username:
        return jsonify({"status": "error", "message": "Username required"}), 400
    db.registrations.insert_one({
        "event_id": ObjectId(event_id),
        "username": username
    })
    return jsonify({"status": "registered"})
