def create_user(username):
    return {
        "username": username,
        "role": "student",
        "interests": [],
        "skills": [],
        "hours_logged": 0
    }
